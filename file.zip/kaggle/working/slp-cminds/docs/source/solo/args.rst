Args
====

dataset
-------

dataset_args
~~~~~~~~~~~~

.. autofunction:: solo.args.dataset.dataset_args
   :noindex:


augmentations_args
~~~~~~~~~~~~~~~~~~

.. autofunction:: solo.args.dataset.augmentations_args
   :noindex:


setup
-----

parse_args_pretrain
~~~~~~~~~~~~~~~~~~~

.. autofunction:: solo.args.setup.parse_args_pretrain
   :noindex:


parse_args_linear
~~~~~~~~~~~~~~~~~

.. autofunction:: solo.args.setup.parse_args_linear
   :noindex:


utils
-----

parse_args_pretrain
~~~~~~~~~~~~~~~~~~~

.. autofunction:: solo.args.utils.additional_setup_pretrain
   :noindex:


parse_args_linear
~~~~~~~~~~~~~~~~~

.. autofunction:: solo.args.utils.additional_setup_linear
   :noindex:
