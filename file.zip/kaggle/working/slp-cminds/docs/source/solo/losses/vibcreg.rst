VIbCReg
-------

.. autofunction:: solo.losses.vibcreg.vibcreg_loss_func
   :noindex:
