SimCLR
------

.. autofunction:: solo.losses.simclr.simclr_loss_func
   :noindex:
