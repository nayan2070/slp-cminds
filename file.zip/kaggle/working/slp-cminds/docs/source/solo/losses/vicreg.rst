VICReg
------

.. autofunction:: solo.losses.vicreg.vicreg_loss_func
   :noindex:
