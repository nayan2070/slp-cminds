Barlow Twins
------------

.. autofunction:: solo.losses.barlow.barlow_loss_func
   :noindex:
