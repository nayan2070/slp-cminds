MAE
---

.. autofunction:: solo.losses.mae.mae_loss_func
   :noindex:
