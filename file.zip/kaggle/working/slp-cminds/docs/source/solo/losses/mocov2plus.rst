MoCo-V2
-------

.. autofunction:: solo.losses.mocov2plus.mocov2plus_loss_func
   :noindex:
