MoCo-V2
=======


.. automethod:: solo.methods.mocov2plus.MoCoV2Plus.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.mocov2plus.MoCoV2Plus.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.mocov2plus.MoCoV2Plus.learnable_params
   :noindex:

momentum_pairs
~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.mocov2plus.MoCoV2Plus.momentum_pairs
   :noindex:

_dequeue_and_enqueue
~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.mocov2plus.MoCoV2Plus._dequeue_and_enqueue
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.mocov2plus.MoCoV2Plus.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.mocov2plus.MoCoV2Plus.training_step
   :noindex:
