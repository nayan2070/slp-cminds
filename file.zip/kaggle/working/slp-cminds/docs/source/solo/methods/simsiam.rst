SimSiam
=======


.. automethod:: solo.methods.simsiam.SimSiam.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.simsiam.SimSiam.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.simsiam.SimSiam.learnable_params
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.simsiam.SimSiam.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.simsiam.SimSiam.training_step
   :noindex:
