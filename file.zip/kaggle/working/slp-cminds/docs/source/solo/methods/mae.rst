MAE
===


.. automethod:: solo.methods.mae.MAE.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.mae.MAE.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.mae.MAE.learnable_params
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.mae.MAE.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.mae.MAE.training_step
   :noindex:
