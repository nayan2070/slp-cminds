VIbCReg
=======


.. automethod:: solo.methods.vibcreg.VIbCReg.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.vibcreg.VIbCReg.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.vibcreg.VIbCReg.learnable_params
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.vibcreg.VIbCReg.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.vibcreg.VIbCReg.training_step
   :noindex:
