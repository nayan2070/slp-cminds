SwAV
====


.. automethod:: solo.methods.swav.SwAV.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.swav.SwAV.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.swav.SwAV.learnable_params
   :noindex:

on_train_start
~~~~~~~~~~~~~~
.. automethod:: solo.methods.swav.SwAV.on_train_start
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.swav.SwAV.forward
   :noindex:

get_assignments
~~~~~~~~~~~~~~~
.. automethod:: solo.methods.swav.SwAV.get_assignments
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.swav.SwAV.training_step
   :noindex:

on_after_backward
~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.swav.SwAV.on_after_backward
   :noindex:
