DINO
====


.. automethod:: solo.methods.dino.DINO.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.dino.DINO.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.dino.DINO.learnable_params
   :noindex:

momentum_pairs
~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.dino.DINO.momentum_pairs
   :noindex:

clip_gradients
~~~~~~~~~~~~~~
.. automethod:: solo.methods.dino.DINO.clip_gradients
   :noindex:


forward
~~~~~~~
.. automethod:: solo.methods.dino.DINO.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.dino.DINO.training_step
   :noindex:

on_after_backward
~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.dino.DINO.on_after_backward
   :noindex:
